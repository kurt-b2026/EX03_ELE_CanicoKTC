/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_ele_canicoktc;

/**
 *
 * @author ELECTRON
 */
public class Game {
    private String name;
    private double gameYear;
    private int sizeMB;
    
    public Game(String n, double g, int s){
        name = n;
        gameYear = g;
        sizeMB = s;
    }
}
