/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_ele_canicoktc;

/**
 *
 * @author ELECTRON
 */
public class Singer {
    private String name;
    String favoriteSong;
    private int noOfPerformances;
    double profits;
    double earnings = 100;
    static int totalPerformances;
    
    public static int getTotalPerformances(){
        return totalPerformances;
    }
    
    public String getFavoriteSong(){
        return favoriteSong;
    }
    
    public Singer(Song s, String n, int p){
        favoriteSong = s.title; 
        name = n;
        noOfPerformances = p;
    }
    
    public void performForAudience(int noOfPeople){
        totalPerformances++; 
        noOfPerformances++;
        profits = noOfPeople * earnings;
        System.out.println("Performing for " + noOfPeople + " people. Has performed for " + totalPerformances + " time(s) in total.");
    }
    
    public void performForAudience(int noOfPeople, Singer otherSinger){
        totalPerformances++;
        profits = noOfPeople*100/2;
        System.out.println("Performing for  " + noOfPeople + " people with " + otherSinger.name + ". Both earned " + profits + " dollars each.");
    }
    
    public void changeFavSong(Song x){
        favoriteSong = x.title;
    }
}
