/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex03_ele_canicoktc;

/**
 *
 * @author ELECTRON
 */
public class EX03_ELE_CanicoKTC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // TODO code application logic here
    Game KSP = new Game("Kerbal Space Program", 2.56, 30100);
    Game Dem4 = new Game("Democracy4", 0.167, 793);
    Game SCPSL = new Game("SCP Secret Laboratory", 3.12, 5060);
    Song myWay = new Song("My Way", "Frank Sinatra", 3);
    Song ROYGBIV = new Song("ROYGBIV", "Boards of Canada", 2);
    Singer GrantMacdonalds = new Singer(ROYGBIV, "Grant Macdonalds", 0);
    Singer RedArmyChoir = new Singer(myWay, "Red Army Choir", 0);
    System.out.println("Favorite Song: " + GrantMacdonalds.getFavoriteSong());
    GrantMacdonalds.performForAudience(12);
    GrantMacdonalds.changeFavSong(myWay);
    System.out.println("New Favorite Song: " + GrantMacdonalds.getFavoriteSong() + "\nEarnings: " + GrantMacdonalds.profits);
    GrantMacdonalds.performForAudience(12, RedArmyChoir);
    }
    
}
