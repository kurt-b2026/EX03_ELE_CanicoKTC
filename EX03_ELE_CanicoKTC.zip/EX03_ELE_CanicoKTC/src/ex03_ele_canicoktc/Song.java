/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_ele_canicoktc;

/**
 *
 * @author ELECTRON
 */
public class Song {
    String title;
    private String artist;
    private int length;
    
    public Song(String t, String a, int l){
        title = t;
        artist = a;
        length = l;
    }
}
